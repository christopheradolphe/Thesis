To run the .ipynb, follow these steps:
1. Open "Thesis_Problem_Set.ipynb" in Google Colaboratory.
2. Mount the entire "Data" folder (from the home directory of the zipped folder) into the Google Colaboratory file.
3. Run each section sequentially from top to bottom.