To run the Python file, follow these steps:
1. Ensure the following libraries are installed: pandas, numpy, statsmodels, matplotlib, and yfinance. If these are not already installed, they can be installed using pip.
2. Open the thesis_problem_set.py file in a preferred IDE.
3. Import the four required CSV files from the "Data" Folder, which is located in the home directory of this zipped folder.
4. Run the Python script within your IDE. When you run thesis_problem_set.py, the script will read the data, perform the analyses, and output the results directly in the console.